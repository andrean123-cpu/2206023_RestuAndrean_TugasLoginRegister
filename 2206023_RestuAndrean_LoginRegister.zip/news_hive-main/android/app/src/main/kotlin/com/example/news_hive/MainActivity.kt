package com.example.news_hive

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
